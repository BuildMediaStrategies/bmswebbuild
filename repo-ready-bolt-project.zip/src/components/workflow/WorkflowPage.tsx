import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { useSEO } from "@/lib/seo";
import MetricsStrip from "@/components/MetricsStrip";
import SuperCTA from "@/components/SuperCTA";
import QuickFAQ from "@/components/QuickFAQ";

export interface StepSpec {
  id?: string;
  title: string;
  desc?: string;
  meta?: string;
  icon: JSX.Element;
}

function useActiveStep(ids: string[]) {
  const [active, setActive] = useState(ids[0] ?? "");
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target?.id) setActive(visible.target.id);
      },
      { rootMargin: "-35% 0px -55% 0px", threshold: [0, 0.25, 0.5, 0.75, 1] }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [ids.join("|")]);
  return active;
}

function Node({ icon }: { icon: JSX.Element }) {
  return (
    <div
      className="group grid place-items-center h-12 w-12 rounded-full border border-[rgba(255,255,255,0.16)] bg-black relative
                 shadow-[0_0_0_6px_rgba(255,255,255,0.03)] transition-transform duration-200 will-change-transform
                 focus-within:outline focus-within:outline-2 focus-within:outline-offset-2 focus-within:outline-white/80 pulse"
    >
      {/* subtle pulse ring */}
      <span aria-hidden className="absolute inset-0 rounded-full pointer-events-none" style={{ boxShadow: "0 0 0 0 rgba(255,255,255,0.18)" }} />
      <div className="text-foreground/90 transition-transform duration-200 group-hover:scale-110">{icon}</div>
    </div>
  );
}

interface WorkflowPageProps {
  title: string;
  subtitle?: string;
  steps: StepSpec[];
  showMetrics?: boolean;
  showCTA?: boolean;
  showFAQ?: boolean;
}

export default function WorkflowPage({
  title,
  subtitle,
  steps,
  showMetrics = true,
  showCTA = true,
  showFAQ = true,
}: WorkflowPageProps) {
  useSEO();
  
  const withIds = useMemo(
    () => steps.map((s, i) => ({ ...s, id: s.id ?? `step-${String(i + 1).padStart(2, "0")}` })),
    [steps]
  );
  const ids = withIds.map((s) => s.id!);
  const active = useActiveStep(ids);

  // keyboard: j/k or ArrowDown/Up to jump steps
  const containerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const idx = ids.indexOf(active);
      if (["j", "J", "ArrowDown"].includes(e.key)) {
        e.preventDefault();
        const n = Math.min(idx + 1, ids.length - 1);
        document.getElementById(ids[n])?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      if (["k", "K", "ArrowUp"].includes(e.key)) {
        e.preventDefault();
        const p = Math.max(idx - 1, 0);
        document.getElementById(ids[p])?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, ids]);

  return (
    <main ref={containerRef} className="section">
      <div className="mx-auto max-w-6xl px-4">
        <header className="mb-10">
          <h1 className="text-3xl md:text-5xl font-bold leading-tight">{title}</h1>
          {subtitle && <p className="mt-3 text-foreground/70 max-w-prose">{subtitle}</p>}
        </header>
      </div>

      <section className="relative mx-auto max-w-6xl px-4">
        {/* center spine */}
        <div aria-hidden className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-[rgba(255,255,255,0.08)]" />

        {/* progress rail (desktop) */}
        <nav
          aria-label="Workflow progress"
          className="hidden lg:flex flex-col gap-3 sticky top-24 float-right -mr-24"
          style={{ alignItems: "flex-start" }}
        >
          {withIds.map((s, i) => {
            const is = active === s.id;
            return (
              <a
                key={s.id}
                href={`#${s.id}`}
                className={`text-sm transition ${is ? "text-foreground" : "text-foreground/50"} hover:text-foreground`}
              >
                {String(i + 1).padStart(2, "0")} {s.title}
              </a>
            );
          })}
        </nav>

        {/* mobile pills */}
        <div className="lg:hidden sticky top-16 z-10 -mx-4 mb-4 bg-[rgba(0,0,0,0.7)]/70 backdrop-blur">
          <div className="flex gap-2 overflow-x-auto px-4 py-3">
            {withIds.map((s, i) => {
              const is = active === s.id;
              return (
                <a
                  key={s.id}
                  href={`#${s.id}`}
                  className={`whitespace-nowrap rounded-full border px-3 py-1 text-xs ${
                    is ? "border-foreground text-foreground" : "border-foreground/30 text-foreground/70"
                  }`}
                >
                  {String(i + 1).padStart(2, "0")}
                </a>
              );
            })}
          </div>
        </div>

        <ol className="space-y-14 clear-right">
          {withIds.map((s, i) => {
            const side = i % 2 === 0 ? "mr-0 lg:mr-[58%]" : "ml-0 lg:ml-[58%]";
            const connectorSide = i % 2 === 0 ? "right-[50%]" : "left-[50%]";
            const portSide = i % 2 === 0 ? "left-0 -translate-x-1/2" : "right-0 translate-x-1/2";
            return (
              <li key={s.id} id={s.id!} className="relative scroll-mt-28">
                {/* Node at spine */}
                <div className="absolute left-1/2 -translate-x-1/2 z-20">
                  <Node icon={s.icon} />
                </div>

                {/* Connector: desktop-only, stops at card edge; brightens on hover of the card */}
                <div
                  aria-hidden
                  className={`pointer-events-none absolute top-[32px] z-20 hidden lg:block ${connectorSide}
                              h-px bg-[rgba(255,255,255,0.28)] transition-colors duration-200`}
                  style={{ width: "calc(8% - 14px)" }}
                />

                {/* Card */}
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.01, y: -2 }}
                  transition={{ type: "tween", duration: 0.2 }}
                  className={`relative z-10 ${side}`}
                >
                  <div
                    className="group relative rounded-2xl border border-[rgba(255,255,255,0.12)]
                               bg-[rgba(255,255,255,0.03)] backdrop-blur-sm p-5 pressable hover-glow"
                  >
                    {/* Port on card edge */}
                    <span
                      aria-hidden
                      className={`absolute top-[28px] z-30 hidden lg:block h-3 w-3 rounded-full
                                  border border-[rgba(255,255,255,0.24)] bg-black ${portSide}`}
                    />

                    <h3 className="text-base md:text-lg font-semibold">
                      {String(i + 1).padStart(2, "0")} · {s.title}
                    </h3>
                    {s.desc && <p className="mt-2 text-sm text-foreground/70">{s.desc}</p>}
                    {s.meta && <p className="mt-3 text-xs text-foreground/50">{s.meta}</p>}
                  </div>
                </motion.div>
              </li>
            );
          })}
        </ol>
      </section>

      {/* Global sections under every workflow */}
      {showMetrics && (
        <MetricsStrip
          items={[
            { label: "Reply/show lift", value: 32, suffix: "%" },
            { label: "Time saved /wk", value: 14, suffix: "h" },
            { label: "Lower handling cost", value: 27, suffix: "%" },
            { label: "Faster shipping", value: 5, suffix: "x" },
          ]}
        />
      )}
      {showCTA && (
        <SuperCTA
          title="Ready to turn this workflow into ROI?"
          bullets={["Increase replies & shows", "Cut manual ops cost", "Ship iterations weekly"]}
          primaryHref="/book"
          primaryLabel="Book a Call"
          secondaryHref="/book"
          secondaryLabel="Talk to Us"
        />
      )}
      {showFAQ && <QuickFAQ />}
    </main>
  );
}