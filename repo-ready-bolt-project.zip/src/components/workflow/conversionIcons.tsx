export const BoltNewIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
    <rect x="3.5" y="3.5" width="17" height="17" rx="3" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M13 3L7 13h5l-1 8 6-10h-5z" />
  </svg>
);

export const BoltCloudIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
    <path d="M7 18a4 4 0 0 1 0-8 5.5 5.5 0 0 1 10.5-1.8A3.5 3.5 0 1 1 18.5 18H7z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M13 9l-4 6h3l-1 4 5-7h-3z" />
  </svg>
);

export const SupabaseIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M13 3c-4 3-6.5 6.5-8 11 2.5-1.5 5-2 8-2v5l6-8c-1.5-2.5-3.5-4-6-6z" />
  </svg>
);

export const GitHubIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
    <circle cx="12" cy="12" r="9" />
    <path d="M9.5 15.5c-2 .5-2-1-3-1m12 0c-1 0-1 1.5-3 1m-6-2.5c-1.5 0-2.5-1-2.5-2.5 0-.8.3-1.5.8-2-.1-.5 0-1.2.2-1.7 1.2 0 2 .6 2.5 1 .6-.2 1.3-.3 2-.3s1.4.1 2 .3c.5-.4 1.3-1 2.5-1 .2.5.3 1.2.2 1.7.5.5.8 1.2.8 2 0 1.5-1 2.5-2.5 2.5" />
  </svg>
);

export const DyadIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4c-4.4 0-8 3.6-8 8s3.6 8 8 8" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4c4.4 0 8 3.6 8 8s-3.6 8-8 8" />
    <path d="M8.5 12a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0-7 0z" />
  </svg>
);