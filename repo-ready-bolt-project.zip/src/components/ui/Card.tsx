import { ReactNode } from "react";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-line bg-muted/60 backdrop-blur-sm p-5 md:p-6 transition-transform duration-300 hover:-translate-y-1 ${className}`}>
      {children}
    </div>
  );
}

export function IconRound({ children }: { children: ReactNode }) {
  return (
    <div className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-line">
      {children}
    </div>
  );
}